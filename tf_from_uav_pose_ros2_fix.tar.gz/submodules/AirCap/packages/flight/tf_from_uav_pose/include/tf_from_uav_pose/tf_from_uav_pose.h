//
// tv_from_uav_poses_node.h
// C++11 is required. Deal with it!
//

#ifndef TF_FROM_UAV_POSE_H
#define TF_FROM_UAV_POSE_H

#include <rclcpp/rclcpp.hpp>
#include <rclcpp/logging.hpp>
#include <tf2_ros/transform_broadcaster.h>
#include <tf2_ros/static_transform_broadcaster.h>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <geometry_msgs/msg/pose_with_covariance_stamped.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <uav_msgs/msg/uav_pose.hpp>

// #include <dynamic_reconfigure/server.h> - // dynamic_reconfigure not available in ROS2
// #include <tf_from_uav_pose/ReconfigureParamsConfig.h> - // removed for ROS2

namespace tf_from_uav_pose {

    void uavCovariance_to_rosCovariance(const uav_msgs::uav_pose::ConstPtr &uav_msg,
                                        geometry_msgs::PoseWithCovariance &std_pose_cov);

    class tfFromUAVPose {

    private:
        auto pnh_ = rclcpp::Node::make_shared("node_name"){"~"};
        auto nh_ = rclcpp::Node::make_shared("node_name");

        rclcpp::Subscription<>::SharedPtr poseSub_;
        rclcpp::Subscription<>::SharedPtr rawPoseSub_;
        rclcpp::Publisher<>::SharedPtr stdPosePub_;
        rclcpp::Publisher<>::SharedPtr stdRawPosePub_;
        rclcpp::Publisher<>::SharedPtr throttledPosePub_;
        std::unique_ptr<ros::Publisher> cameraPosePub_, camRGBPosePub_;
        std::unique_ptr<tf2_ros::TransformBroadcaster> tfBroadcaster_;
        std::unique_ptr<tf2_ros::StaticTransformBroadcaster> statictfBroadcaster_;

        geometry_msgs::PoseWithCovarianceStamped stdPose_, stdRawPose_, camRobPose_, rgbCamPose_;
        geometry_msgs::PoseStamped throttledPose_;
        geometry_msgs::TransformStamped tfPose_;
        geometry_msgs::TransformStamped tfWorldENU_;
        geometry_msgs::TransformStamped tfWorldNWU_;
        geometry_msgs::TransformStamped tfCamRGB_;

        dynamic_reconfigure::Server<ReconfigureParamsConfig> dyn_rec_server_;

        ///@TODO remove this hacked offset, do it better
        std::vector<double> offset_{0, 0, 0};
        std::vector<double> added_covariance_{0, 0, 0};
	double throttleRate_{10.0};

        bool dontPublishTFs_{false};

    public:
        tfFromUAVPose();

        void dynamicReconfigureCallback(ReconfigureParamsConfig &config, uint32_t level);

        void poseCallback(const uav_msgs::uav_pose::ConstPtr &msg);
        void rawPoseCallback(const uav_msgs::uav_pose::ConstPtr &msg);
    };
}

#endif //TF_FROM_UAV_POSE_H
