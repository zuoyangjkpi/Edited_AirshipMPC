// Provides a sensor_msgs/CameraInfo message in a latched topic
// Info is read from URL using the camera_info_manager interface
//

#include <rclcpp/rclcpp.hpp>
#include <camera_info_manager/camera_info_manager.hpp>
#include <sensor_msgs/msg/camera_info.hpp>

int main(int argc, char* argv[]){

  rclcpp::init(argc, argv);

  auto node = rclcpp::Node::make_shared("camera_info_publisher");

  // Parameters
  std::string url;
  node->declare_parameter("camera_info_url", "");
  if(!node->get_parameter("camera_info_url", url) || url.empty()){
    RCLCPP_ERROR(node->get_logger(), "Must provide camera_info_url parameter");
    return EXIT_FAILURE;
  }

  camera_info_manager::CameraInfoManager manager(node.get(), "video", url);

  std::string topic = "camera_info";
  node->declare_parameter("topic", topic);
  node->get_parameter("topic", topic);

  auto pub = node->create_publisher<sensor_msgs::msg::CameraInfo>(topic, rclcpp::QoS(1).transient_local());

  RCLCPP_INFO(node->get_logger(), "Publishing camera_info to topic %s", topic.c_str());

  // Publish once and keep spinning
  pub->publish(manager.getCameraInfo());

  rclcpp::spin(node);

  rclcpp::shutdown();
  return 0;
}

