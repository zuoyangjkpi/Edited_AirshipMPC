// tf_from_uav_pose.h
// ROS2 version

#ifndef TF_FROM_UAV_POSE_H
#define TF_FROM_UAV_POSE_H

#include <rclcpp/rclcpp.hpp>
#include <tf2_ros/transform_broadcaster.h>
#include <tf2_ros/static_transform_broadcaster.h>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <geometry_msgs/msg/pose_with_covariance_stamped.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <uav_msgs/msg/uav_pose.hpp>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

namespace tf_from_uav_pose {

    class tfFromUAVPose : public rclcpp::Node {

    private:
        rclcpp::Subscription<uav_msgs::msg::UavPose>::SharedPtr pose_sub_;
        rclcpp::Subscription<uav_msgs::msg::UavPose>::SharedPtr raw_pose_sub_;
        rclcpp::Publisher<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr std_pose_pub_;
        rclcpp::Publisher<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr std_raw_pose_pub_;
        rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr throttled_pose_pub_;
        
        std::unique_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
        std::unique_ptr<tf2_ros::StaticTransformBroadcaster> static_tf_broadcaster_;

        geometry_msgs::msg::PoseWithCovarianceStamped std_pose_, std_raw_pose_;
        geometry_msgs::msg::PoseStamped throttled_pose_;
        geometry_msgs::msg::TransformStamped tf_pose_;
        geometry_msgs::msg::TransformStamped tf_world_enu_;
        geometry_msgs::msg::TransformStamped tf_world_nwu_;

        std::vector<double> offset_{0.0, 0.0, 0.0};
        std::vector<double> added_covariance_{0.0, 0.0, 0.0};
        double throttle_rate_{10.0};
        bool dont_publish_tfs_{false};
        
        std::string machine_frame_id_{"machine_1_base_link"};
        std::string world_frame_id_{"world"};
        std::string world_enu_frame_id_{"world_ENU"};
        std::string world_nwu_frame_id_{"world_NWU"};

        rclcpp::Time last_throttled_time_;

    public:
        tfFromUAVPose();

        void pose_callback(const uav_msgs::msg::UavPose::SharedPtr msg);
        void raw_pose_callback(const uav_msgs::msg::UavPose::SharedPtr msg);
        void setup_static_transforms();
        void uav_covariance_to_ros_covariance(const uav_msgs::msg::UavPose::SharedPtr &uav_msg,
                                             geometry_msgs::msg::PoseWithCovariance &std_pose_cov);
    };
}

#endif //TF_FROM_UAV_POSE_H

