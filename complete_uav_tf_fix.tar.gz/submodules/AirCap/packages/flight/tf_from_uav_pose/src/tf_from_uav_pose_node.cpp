// tf_from_uav_pose_node.cpp
// ROS2 version

#include <tf_from_uav_pose/tf_from_uav_pose.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

namespace tf_from_uav_pose {

tfFromUAVPose::tfFromUAVPose() : Node("tf_from_uav_pose_node") {
    
    // Declare parameters
    this->declare_parameter("pose_topic_name", "pose");
    this->declare_parameter("raw_pose_topic_name", "pose/raw");
    this->declare_parameter("std_pose_topic_name", "pose/corr/std");
    this->declare_parameter("std_raw_pose_topic_name", "pose/raw/std");
    this->declare_parameter("throttled_pose_topic_name", "throttledPose");
    this->declare_parameter("machine_frame_id", machine_frame_id_);
    this->declare_parameter("world_frame_id", world_frame_id_);
    this->declare_parameter("world_enu_frame_id", world_enu_frame_id_);
    this->declare_parameter("world_nwu_frame_id", world_nwu_frame_id_);
    this->declare_parameter("dont_publish_tfs", dont_publish_tfs_);
    this->declare_parameter("offset_x", offset_[0]);
    this->declare_parameter("offset_y", offset_[1]);
    this->declare_parameter("offset_z", offset_[2]);
    this->declare_parameter("covariance_x", added_covariance_[0]);
    this->declare_parameter("covariance_y", added_covariance_[1]);
    this->declare_parameter("covariance_z", added_covariance_[2]);
    this->declare_parameter("throttle_rate", throttle_rate_);

    // Get parameters
    std::string pose_topic_name = this->get_parameter("pose_topic_name").as_string();
    std::string raw_pose_topic_name = this->get_parameter("raw_pose_topic_name").as_string();
    std::string std_pose_topic_name = this->get_parameter("std_pose_topic_name").as_string();
    std::string std_raw_pose_topic_name = this->get_parameter("std_raw_pose_topic_name").as_string();
    std::string throttled_pose_topic_name = this->get_parameter("throttled_pose_topic_name").as_string();
    machine_frame_id_ = this->get_parameter("machine_frame_id").as_string();
    world_frame_id_ = this->get_parameter("world_frame_id").as_string();
    world_enu_frame_id_ = this->get_parameter("world_enu_frame_id").as_string();
    world_nwu_frame_id_ = this->get_parameter("world_nwu_frame_id").as_string();
    dont_publish_tfs_ = this->get_parameter("dont_publish_tfs").as_bool();
    offset_[0] = this->get_parameter("offset_x").as_double();
    offset_[1] = this->get_parameter("offset_y").as_double();
    offset_[2] = this->get_parameter("offset_z").as_double();
    added_covariance_[0] = this->get_parameter("covariance_x").as_double();
    added_covariance_[1] = this->get_parameter("covariance_y").as_double();
    added_covariance_[2] = this->get_parameter("covariance_z").as_double();
    throttle_rate_ = this->get_parameter("throttle_rate").as_double();

    // Initialize TF broadcasters
    if (!dont_publish_tfs_) {
        RCLCPP_INFO(this->get_logger(), "Subscribing to '%s' and publishing tf with parent '%s' and child '%s'", 
                   pose_topic_name.c_str(), world_frame_id_.c_str(), machine_frame_id_.c_str());
        
        tf_broadcaster_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);
        static_tf_broadcaster_ = std::make_unique<tf2_ros::StaticTransformBroadcaster>(*this);
    } else {
        RCLCPP_INFO(this->get_logger(), "Requested to not publish TFs - Publishing only poses!");
    }

    // Setup publishers
    std_pose_pub_ = this->create_publisher<geometry_msgs::msg::PoseWithCovarianceStamped>(std_pose_topic_name, 10);
    std_raw_pose_pub_ = this->create_publisher<geometry_msgs::msg::PoseWithCovarianceStamped>(std_raw_pose_topic_name, 10);
    throttled_pose_pub_ = this->create_publisher<geometry_msgs::msg::PoseStamped>(throttled_pose_topic_name, 10);

    // Setup subscribers
    pose_sub_ = this->create_subscription<uav_msgs::msg::UavPose>(
        pose_topic_name, 10, std::bind(&tfFromUAVPose::pose_callback, this, std::placeholders::_1));
    raw_pose_sub_ = this->create_subscription<uav_msgs::msg::UavPose>(
        raw_pose_topic_name, 10, std::bind(&tfFromUAVPose::raw_pose_callback, this, std::placeholders::_1));

    // Initialize message headers
    std_pose_.header.frame_id = world_frame_id_;
    std_raw_pose_.header.frame_id = world_frame_id_;
    throttled_pose_.header.frame_id = world_frame_id_;
    tf_pose_.header.frame_id = world_frame_id_;
    tf_pose_.child_frame_id = machine_frame_id_;

    // Setup static transforms
    setup_static_transforms();

    last_throttled_time_ = this->now();

    RCLCPP_INFO(this->get_logger(), "tf_from_uav_pose node initialized");
}

void tfFromUAVPose::setup_static_transforms() {
    if (dont_publish_tfs_) return;

    std::vector<geometry_msgs::msg::TransformStamped> static_tfs;

    // TF from world_ENU to world (world_ENU will be the root of the tree)
    tf_world_enu_.header.stamp = this->now();
    tf_world_enu_.header.frame_id = world_enu_frame_id_;
    tf_world_enu_.child_frame_id = world_frame_id_;
    tf2::Quaternion q_enu;
    q_enu.setRPY(M_PI, 0, M_PI_2);
    tf_world_enu_.transform.rotation = tf2::toMsg(q_enu);
    static_tfs.push_back(tf_world_enu_);

    // TF from world to world_NWU
    tf_world_nwu_.header.stamp = this->now();
    tf_world_nwu_.header.frame_id = world_frame_id_;
    tf_world_nwu_.child_frame_id = world_nwu_frame_id_;
    tf2::Quaternion q_nwu;
    q_nwu.setRPY(0, M_PI, 0);
    tf_world_nwu_.transform.rotation = tf2::toMsg(q_nwu);
    static_tfs.push_back(tf_world_nwu_);

    // Broadcast all static tfs
    static_tf_broadcaster_->sendTransform(static_tfs);
}

void tfFromUAVPose::pose_callback(const uav_msgs::msg::UavPose::SharedPtr msg) {
    // Copy contents to std pose msg
    std_pose_.header.stamp = msg->header.stamp;
    std_pose_.pose.pose.position = msg->position;
    std_pose_.pose.pose.orientation = msg->orientation;

    // Convert covariance types
    uav_covariance_to_ros_covariance(msg, std_pose_.pose);

    // Add offset
    std_pose_.pose.pose.position.x += offset_[0];
    std_pose_.pose.pose.position.y += offset_[1];
    std_pose_.pose.pose.position.z += offset_[2];

    std_pose_.pose.covariance[0] += added_covariance_[0];
    std_pose_.pose.covariance[7] += added_covariance_[1];
    std_pose_.pose.covariance[14] += added_covariance_[2];

    // Publish std pose msg
    std_pose_pub_->publish(std_pose_);

    // Handle throttled pose
    rclcpp::Duration time_diff = msg->header.stamp - last_throttled_time_;
    if (time_diff.seconds() >= (1.0 / throttle_rate_)) {
        throttled_pose_.header.stamp = msg->header.stamp;
        throttled_pose_.pose.position = msg->position;
        throttled_pose_.pose.orientation = msg->orientation;
        throttled_pose_pub_->publish(throttled_pose_);
        last_throttled_time_ = msg->header.stamp;
    }

    // Copy contents to tf msgs and broadcast
    if (!dont_publish_tfs_) {
        tf_pose_.header.stamp = msg->header.stamp;
        tf_pose_.transform.translation.x = std_pose_.pose.pose.position.x;
        tf_pose_.transform.translation.y = std_pose_.pose.pose.position.y;
        tf_pose_.transform.translation.z = std_pose_.pose.pose.position.z;
        tf_pose_.transform.rotation = std_pose_.pose.pose.orientation;
        tf_broadcaster_->sendTransform(tf_pose_);
    }
}

void tfFromUAVPose::raw_pose_callback(const uav_msgs::msg::UavPose::SharedPtr msg) {
    // Copy contents to std raw pose msg
    std_raw_pose_.header.stamp = msg->header.stamp;
    std_raw_pose_.pose.pose.position = msg->position;
    std_raw_pose_.pose.pose.orientation = msg->orientation;

    // Convert covariance types
    uav_covariance_to_ros_covariance(msg, std_raw_pose_.pose);

    // Publish std raw pose msg
    std_raw_pose_pub_->publish(std_raw_pose_);
}

void tfFromUAVPose::uav_covariance_to_ros_covariance(const uav_msgs::msg::UavPose::SharedPtr &uav_msg,
                                                    geometry_msgs::msg::PoseWithCovariance &std_pose_cov) {
    // Simplified covariance conversion - just copy position covariances
    // For a full implementation, you would need MRPT library
    
    // Initialize covariance matrix to zero
    std::fill(std_pose_cov.covariance.begin(), std_pose_cov.covariance.end(), 0.0);
    
    // Copy position covariances (first 3x3 block)
    if (uav_msg->covariance.size() >= 100) {
        // Position covariances (north, east, down)
        std_pose_cov.covariance[0] = uav_msg->covariance[0];   // xx
        std_pose_cov.covariance[7] = uav_msg->covariance[11];  // yy  
        std_pose_cov.covariance[14] = uav_msg->covariance[22]; // zz
        
        // Set some default orientation covariances
        std_pose_cov.covariance[21] = 0.01; // roll
        std_pose_cov.covariance[28] = 0.01; // pitch
        std_pose_cov.covariance[35] = 0.01; // yaw
    }
}

} // namespace tf_from_uav_pose

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<tf_from_uav_pose::tfFromUAVPose>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}

