/*
 * TODO: Add apropriate License and copyright header
 */

#include "replay.h"

int main(int argc, char * *argv)
{
    replay::replay replay(argc, argv);

    return replay.run();
}
