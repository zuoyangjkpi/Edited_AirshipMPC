/*
 * TODO: Add apropriate License and copyright header
 */

#include "videograb.h"

int main(int argc, char * *argv)
{
    videograb::videograb videograb(argc, argv);

    return videograb.run();
}
