//
// Provides a sensor_msgs/CameraInfo message in a latched topic
// Info is read from URL using the camera_info_manager interface
//

#include <rclcpp/rclcpp.hpp>
#include <camera_info_manager/camera_info_manager.h>

int main(int argc, char* argv[]){

  rclcpp::init(argc, argv);

  auto nh = rclcpp::Node::make_shared("node_name");
  auto pnh = rclcpp::Node::make_shared("node_name")("~");

  // Parameters
  std::string url;
  if(!pnh.getParam("camera_info_url", url)){
    RCLCPP_ERROR(node->get_logger(), "Must provide camera_info_url parameter");
    return EXIT_FAILURE;
  }
  camera_info_manager::CameraInfoManager manager(nh, "video", url);

  std::string topic{"camera_info"};
  pnh.getParam("camera_info_topic", topic);

  rclcpp::Publisher<>::SharedPtr pub = nh.advertise<sensor_msgs::CameraInfo>(topic, 1, true);

  RCLCPP_INFO(node->get_logger(), "Publishing camera_info to topic %s", pub.getTopic().c_str());

  // Publish once, then just spin because it's a latched topic
  pub.publish(manager.getCameraInfo());

  rclcpp::spin(node);

  return EXIT_SUCCESS;
}
