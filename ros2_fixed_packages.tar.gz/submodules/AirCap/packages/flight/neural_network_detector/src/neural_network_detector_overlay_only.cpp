//
// Created by glawless on 01.09.17.
//

#include <neural_network_detector/Overlay.h>

int main(int argc, char *argv[]) {

    rclcpp::init(argc, argv);

    neural_network_detector::Overlay overlay;

    rclcpp::spin(node);

    return EXIT_SUCCESS;
}