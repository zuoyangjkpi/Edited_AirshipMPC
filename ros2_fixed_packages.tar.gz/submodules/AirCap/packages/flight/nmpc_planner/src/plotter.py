#!/usr/bin/env python
import sys
import rclpy
from rclpy.node import Node
from uav_msgs.msg import uav_pose
from matplotlib import pyplot as plt

def callback(data):
	global counter
	counter += 1	
	#node.get_logger().info(data.position)
	# if counter%10 == 0:
	# 	plt.plot(data.position.x, data.position.y, '*')
 #        plt.axis([-20,20,-20,20])
 #        plt.draw()
 #        plt.pause(0.00000000001)


def listener():
	rclpy.init()
node = Node("node_name");	
	topic = '/waypoint_firefly_'+str(sys.argv[1])
	node.create_subscription(topic, uav_pose, callback)

	rclpy.spin(node)

if __name__ == '__main__':
	counter = 0;
	listener()