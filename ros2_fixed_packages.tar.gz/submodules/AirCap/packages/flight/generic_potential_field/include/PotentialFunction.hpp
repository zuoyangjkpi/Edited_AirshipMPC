#ifndef POTENTIALFUNCTION_HPP_
#define POTENTIALFUNCTION_HPP_

#include <cstdio>
#include <iostream>
#include <string>

#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>
#include <std_msgs/Int8.h>
#include <std_msgs/Float32.h>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <geometry_msgs/PoseArray.h>
#include <geometry_msgs/msg/pose.hpp>
#include <geometry_msgs/msg/vector3.hpp>
#include <geometry_msgs/QuaternionStamped.h>
#include <sensor_msgs/msg/imu.hpp>
#include <uav_msgs/uav_pose.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

#include <boost/bind.hpp>
#include <boost/ref.hpp>
#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>

#include <algorithm>
#include <Eigen/Sparse>
#include <unsupported/Eigen/KroneckerProduct> // C = kroneckerProduct(A,B);


#include <sys/time.h> 

enum PotentialFunctionType { Attractive, Repulsive};

class PotentialFunction
{

protected:
	PotentialFunctionType type;

	void updateBoundsValues();
              

public:
	PotentialFunction(const std::string& potentialFunctionName_, PotentialFunctionType type_);
        
	PotentialFunction(const std::string& potentialFunctionName_, PotentialFunctionType type_,
			double tPotFuncZeroD_, double tPotFuncInfD_, double tPotFuncSatValue_, double tPotFuncGain_);
        


	// get Type
	PotentialFunctionType getType() const;

	double getPotential(double d, double threshold) const;
	// Pure virtual, overwrite
	virtual double getPotentialImpl(double d,double threshold) const = 0;
        
	double tPotFuncZeroD;
	double tPotFuncInfD;
	double tPotFuncSatValue;
	double tPotFuncGain;          

};

#endif /* POTENTIALFUNCTION_HPP_ */
