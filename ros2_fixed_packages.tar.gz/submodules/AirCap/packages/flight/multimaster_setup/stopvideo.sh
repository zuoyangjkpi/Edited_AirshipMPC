#!/bin/bash

rostopic pub -v -1 /global/record std_msgs/UInt8 "0"
