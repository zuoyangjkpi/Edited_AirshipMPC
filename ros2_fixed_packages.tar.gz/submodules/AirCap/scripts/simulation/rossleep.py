#!/usr/bin/python


import rclpy
from rclpy.node import Node
import os
import sys


duration=(float)(sys.argv[1])


rclpy.init()
node = Node("node_name")

node.get_logger().info("sleeping for %f seconds"%duration)

rospy.sleep(duration)
node.get_logger().info("done")
